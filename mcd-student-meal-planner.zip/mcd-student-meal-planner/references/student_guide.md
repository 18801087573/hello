# 大学生点餐链路参考（数据格式与估算模型）

## 一、营养数据格式（list-nutrition-foods）

MCP 返回 `data` 文本，首行为表头（形如 `160]{productName,...,calcium}:`），数据行逗号分隔：

```
名称,null,能量kJ,能量kcal,蛋白质g,脂肪g,碳水g,钠mg,钙mg
```

将返回的 `data` 原样写入临时文件传给 `scripts/planner.py recommend --data`。若 MCP 不可用，可借用兄弟技能 `mcd-menu-recommender/references/nutrition_data.txt` 离线快照（需注明可能非最新）。

## 二、价格文件格式（query-meals 整理）

```json
[{"name": "板烧鸡腿堡", "price": 25.5}, ...]
```

预算模式必须提供；价格与门店相关，先 `query-nearby-stores` 拿 `storeCode` 再 `query-meals`。

## 三、配送时间估算模型（planner.py delivery）

麦当劳 MCP 无"预计配送时长"接口，采用确定性估算：

```
基础 = 出餐 8 min + 骑手接单 5 min + 骑行(距离/20km/h) + 交接 4 min
系数叠加：午/晚高峰(10:45-13:00, 16:45-19:00) ×1.3
          小雨 ×1.3；暴雨/雪 ×1.6 且 +10 min；酷热 ×1.1
校园取餐（闸机/电梯/外卖柜排队）+5 min
突发缓冲：输出 [估计, 估计+缓冲] 区间，默认缓冲 8 min
```

距离来源：用户位置与门店位置（地图/常识估算 km 数，让用户确认）；外卖单也可用
`delivery-query-stores` 确认门店是否开通外送、`delivery-query-addresses` 确认配送地址。

规划原则：**按区间上限（最坏情况）规划**——宁可人等餐，不可餐等人。

## 四、最优下单时间（planner.py order-time）

目标：骑手在「下课时间 + 教室走到取餐点步行时间」时送达。

```
目标取餐时刻 = 下课时间 + walk_min（默认 5 min）
下单窗口   = [目标 - eta_max, 目标 - eta_min]
推荐下单时刻 = 目标 - (eta_min + eta_max)/2
```

- 若麦当劳 App 支持"预约送达"，直接预约送达时间 = 目标取餐时刻，比掐点下单更稳。
- 课表由用户在对话中粘贴或上传（图片可识别）；解析出当日最后一节课的下课后，
  需向用户复述确认下课时间无误后再计算。

## 五、下单执行边界

默认只推荐到"下单时间"为止。用户明确同意后，才可调用 `mcp__mcd-mcp__create-order`
生成订单并进入支付；下单前必须复述订单内容、金额、收货地址供用户确认。
