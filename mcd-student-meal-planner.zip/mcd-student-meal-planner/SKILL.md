---
name: mcd-student-meal-planner
description: 大学生麦当劳点餐规划技能。当用户是学生、想"按预算点麦当劳/上课犯困吃什么防困餐/低碳水推荐/查附近麦当劳外卖店/算配送时间/根据课程表推算下单时间/下课即取餐"时使用。整合麦当劳 MCP（营养、价格、门店、外送、下单）与内置防困知识库、确定性计算脚本 planner.py，覆盖"预算套餐 → 营养/低碳水 → 防困推荐 → 门店与配送时间（含突发缓冲）→ 依课表推最优下单时间 → 询问是否代下单"全链路。
---

# 大学生麦当劳点餐规划 (mcd-student-meal-planner)

## Overview

面向大学生场景的麦当劳点餐全链路技能：按预算推荐套餐 → 查营养素与低碳水食品 → 结合内置防困知识库推荐防困餐 → 定位附近外卖门店并估算配送时间（计入高峰、天气、商家爆单等突发情况的缓冲区间）→ 询问是否需要推荐下单时间 → 若需要则读取课程表，与用户确认下课时间后反推最优下单时间，实现"下课即取餐"。所有数值计算经 `scripts/planner.py` 完成，保证可重复、无歧义。

## When to Use

- "我只有 30 块，麦当劳怎么点"（预算套餐）
- "下午有课，吃什么不犯困 / 防困餐 / 低碳水推荐"（防困、低碳水）
- "查一下这个套餐的营养素 / 热量、碳水多少"（营养查询）
- "找附近的麦当劳外卖店 / 配送要多久"（门店与配送时间）
- "我几点下单才能下课后正好拿到外卖 / 下课即取餐"（课表联动、最优下单时间）

## Workflow（按用户需求选择性执行，非每次全跑）

### Step 1 — 预算推荐套餐

1. 调 `mcp__mcd-mcp__list-nutrition-foods` 取营养数据；预算模式还需 `query-nearby-stores`（拿 `storeCode`）+ `query-meals`（拿价格）。
2. 营养文本存临时文件，价格整理为 `[{"name":...,"price":...}]` JSON（格式见 `references/student_guide.md`）。
3. 运行：

```bash
python <skill_dir>/scripts/planner.py recommend --data <营养文件> --prices <价格文件> --budget 30 --goal balanced
```

4. 按 Top 结果向用户呈现组合与金额；用户未给预算时先询问预算额。

### Step 2 — 营养素查询 / 低碳水筛选

- 查单品营养：直接读营养数据中对应行（热量 kcal、蛋白、脂肪、碳水 g、钠 mg、钙 mg），或按用户指名单品调用 `mcp__mcd-mcp__query-meal-detail` 补充构成。
- 低碳水推荐：`planner.py recommend --data <营养文件> --goal low_carb`（脚本自动过滤碳水 > 30 g 与油炸品）。

### Step 3 — 防困餐推荐

1. 读 `references/anti_sleep_foods.md`（内置知识库：高GI碳水/高脂 → 胰岛素 → 血清素/褪黑素 → 犯困；对策为低碳水、高蛋白、控总量、无糖饮品）。该库为缓存结论并标注了检索日期；用户要求最新依据时先 WebSearch 刷新。
2. 运行 `planner.py recommend --data <营养文件> --goal anti_sleep`，脚本按防困分排序（碳水供能占比降分、蛋白加分、油炸/含糖饮料重罚、总热量 ≤ 850 kcal 保七八分饱）。
3. 呈现组合时附一句防困原理与进食顺序建议（先吃肉蛋、后吃主食）。

### Step 4 — 附近外卖门店与配送时间

1. `mcp__mcd-mcp__query-nearby-stores` 按用户位置查门店；外送单用 `delivery-query-stores` 确认开通外送、`delivery-query-addresses` 确认地址。
2. 估算距离 km（与用户确认）；运行：

```bash
python <skill_dir>/scripts/planner.py delivery --distance-km 1.5 --order-time 11:40 --peak auto --weather normal
```

3. 模型：出餐 8 min + 接单 5 min + 骑行(距离/20km/h) + 交接 4 min；高峰 ×1.3、雨 ×1.3、暴雨/雪 ×1.6 且 +10 min、酷热 ×1.1；校园取餐 +5 min；再叠 8 min 突发缓冲（商家爆单/骑手不足/路况/取餐排队）。输出**送达时间区间**，按上限规划。

### Step 5 — 询问是否需要推荐下单时间

主动问用户："需要我根据你的课表推荐最优下单时间吗？" 不需要则止步于 Step 4。

### Step 6 — 课表联动推算最优下单时间（下课即取餐）

1. 请求用户在对话中粘贴文字课表或上传课表图片/文件；解析出目标节课的下课时间。
2. **向用户复述并确认下课时间**（如"你最后一节 17:30 下，对吗？"），确认后才计算。
3. 运行：

```bash
python <skill_dir>/scripts/planner.py order-time --class-end 17:30 --eta-min <配送下限min> --eta-max <配送上限min> --walk-min 5
```

4. 输出下单窗口与推荐下单时刻；提示若 App 支持"预约送达"，直接预约送达时间 = 目标取餐时刻更稳。
5. **下单边界**：默认只推荐时间。若用户同意代下单，复述订单内容、金额、地址供确认后，调用 `mcp__mcd-mcp__create-order` 生成订单并进入支付流程。

## 可用麦当劳 MCP 工具速查

| 工具 | 用途 |
|------|------|
| `list-nutrition-foods` | 营养数据主干（能量/蛋白/脂肪/碳水/钠/钙），Step 1/2/3 必用 |
| `query-meals` | 餐品价格（需 storeCode/orderType/beType），预算模式必用 |
| `query-meal-detail` | 单品构成说明 |
| `query-nearby-stores` | 查附近门店拿 storeCode |
| `delivery-query-stores` / `delivery-query-addresses` | 外送门店/配送地址确认 |
| `query-promotions` / `query-store-coupons` | 优惠叠加（可选） |
| `now-time-info` | 判断当前时段（高峰、早餐时段） |
| `create-order` | 仅在用户明确同意后代下单（Step 6） |

## Resources

- `scripts/planner.py`：确定性计算引擎，三子命令 `recommend`（预算/防困/低碳水推荐）、`delivery`（含突发缓冲的配送区间）、`order-time`（反推最优下单时间），仅依赖 Python 标准库。
- `references/anti_sleep_foods.md`：防困知识库（犯困机理 + 饮食对策 + 麦当劳友好/规避清单），含检索日期，可按需联网刷新。
- `references/student_guide.md`：营养/价格数据格式、配送估算模型细节、下单时间公式、下单执行边界。

## 注意事项

- 营养与价格为标准配方/实时返回值，实际出品与价格可能有偏差。
- 配送时间为估算区间，非官方承诺；遇极端天气或用餐高峰务必按上限规划并提醒用户。
- 咖啡因提神注意不影响夜间睡眠；本技能不构成医疗或营养处方。
