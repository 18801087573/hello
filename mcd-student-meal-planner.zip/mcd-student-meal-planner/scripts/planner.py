# -*- coding: utf-8 -*-
"""
mcd-student-meal-planner 确定性计算引擎（仅依赖 Python 标准库）。

三个子命令：
  recommend   按预算 / 防困 / 低碳水目标从麦当劳营养数据（可选叠加价格）中生成并排序套餐组合
  delivery    估算外送配送时间区间（含高峰/天气/校园取餐等突发缓冲）
  order-time  根据下课时间 + 配送时间区间，反推最优下单时间
"""
import argparse
import json
import sys

# ---------------------------------------------------------------- 工具函数

def parse_time(s):
    """'HH:MM' -> 分钟数"""
    h, m = s.strip().split(":")
    return int(h) * 60 + int(m)


def fmt_time(minutes):
    minutes = int(round(minutes))
    minutes %= 24 * 60
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


def load_nutrition(path):
    """解析 list-nutrition-foods 返回的文本快照。

    首行形如  160]{productName,nutritionDescription,energyKj,...}:
    数据行:   名称,null,kJ,kcal,蛋白质(g),脂肪(g),碳水(g),钠(mg),钙(mg)
    """
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or "productName" in line or line.endswith("}:"):
                continue
            parts = [p.strip() for p in line.split(",")]
            if len(parts) < 9 or parts[0] in ("null", ""):
                continue
            try:
                rows.append({
                    "name": parts[0],
                    "kj": float(parts[2]),
                    "kcal": float(parts[3]),
                    "protein": float(parts[4]),
                    "fat": float(parts[5]),
                    "carb": float(parts[6]),
                    "sodium": float(parts[7]),
                    "calcium": float(parts[8]),
                })
            except (ValueError, IndexError):
                continue
    return rows


def classify(item):
    """按名称关键词粗分类别。"""
    n = item["name"]
    drinks = ("可乐", "咖啡", "茶", "果汁", "椰", "水", "奶昔", "饮品", "汽水")
    if any(k in n for k in drinks):
        return "drink"
    return "food"


# ---------------------------------------------------------------- 防困评分

FRIED = ("炸", "薯条", "派", "新地", "旋风", "冰淇淋", "圆筒", "鸡块")
ZERO_SUGAR = ("零度", "无糖", "美式", "零", "茶", "水")


def anti_sleep_score(item):
    """防困得分 0~100：低碳水比例、高蛋白、低脂肪、中等热量、无油炸/甜品、无糖饮品加分。"""
    kcal = max(item["kcal"], 1.0)
    carb_ratio = item["carb"] * 4 / kcal          # 碳水供能占比
    protein_ratio = item["protein"] * 4 / kcal    # 蛋白供能占比
    fat_ratio = item["fat"] * 9 / kcal            # 脂肪供能占比
    score = 100.0
    score -= carb_ratio * 70                      # 高GI碳水是犯困主因
    score += protein_ratio * 60                   # 蛋白质稳定血糖、提神
    score -= fat_ratio * 40                       # 高脂刺激胆囊收缩素 → 困
    if any(k in item["name"] for k in FRIED):
        score -= 30                               # 油炸高脂组合是犯困重灾区
    if classify(item) == "drink":
        if any(k in item["name"] for k in ZERO_SUGAR):
            score += 10                           # 无糖饮品/咖啡因
        else:
            score -= 25                           # 含糖饮料血糖飙升
    if 200 <= item["kcal"] <= 600:
        score += 10                               # 七八分饱：中等热量加分
    elif item["kcal"] > 750:
        score -= 10                               # 过饱加重食困
    return max(0.0, min(100.0, score))


def pick_candidates(rows, mode):
    """按模式筛出候选池。"""
    out = []
    for it in rows:
        s = anti_sleep_score(it)
        if mode == "low_carb" and it["carb"] > 30:
            continue
        if mode in ("anti_sleep", "low_carb") and any(k in it["name"] for k in FRIED):
            continue
        out.append((it, s))
    return out


def recommend(args):
    rows = load_nutrition(args.data)
    prices = {}
    if args.prices:
        with open(args.prices, "r", encoding="utf-8") as f:
            for p in json.load(f):
                prices[p["name"]] = float(p["price"])
    excludes = [e.strip() for e in args.exclude.split(",") if e.strip()]
    rows = [r for r in rows if not any(e in r["name"] for e in excludes)]

    mode = args.goal
    cands = pick_candidates(rows, mode)
    if not cands:
        print("没有符合筛条件的餐品，请放宽 --goal / --exclude。")
        return

    foods = [(it, s) for it, s in cands if classify(it) == "food"]
    drinks = [(it, s) for it, s in cands if classify(it) == "drink"]
    foods.sort(key=lambda x: (-x[1], x[0]["kcal"]))
    drinks.sort(key=lambda x: (-x[1], x[0]["kcal"]))

    combos = []
    seen = set()
    mains = foods[:8]
    sides_pool = foods[:12]
    for main, ms in mains:
        for side, ss in sides_pool:
            if side is main or main["name"] == side["name"]:
                continue
            for drink, ds in drinks[:5]:
                total_kcal = main["kcal"] + side["kcal"] + drink["kcal"]
                if total_kcal > 850:                       # 七八分饱上限
                    continue
                names = [main["name"], side["name"], drink["name"]]
                key = frozenset(names)
                if key in seen:
                    continue
                seen.add(key)
                if prices:
                    entry_prices = [prices[x["name"]] for x in (main, side, drink)
                                    if x["name"] in prices]
                    price = round(sum(entry_prices), 1)
                    partial = len(entry_prices) < 3   # 缺价时价格仅为已知下限
                else:
                    price, partial = None, False
                if args.budget and prices and (price is None or price > args.budget):
                    continue
                combo_score = (ms + ss + ds) / 3
                carb = main["carb"] + side["carb"] + drink["carb"]
                protein = main["protein"] + side["protein"] + drink["protein"]
                combos.append({
                    "items": names,
                    "score": round(combo_score, 1),
                    "kcal": round(total_kcal),
                    "carb": round(carb, 1),
                    "protein": round(protein, 1),
                    "price": price,
                    "price_partial": partial,
                })
                break   # 每个主+副食只配当前最优饮品，控制组合数
    if not combos:
        print("未生成组合：预算/热量约束过紧，或价格数据缺失（预算模式需 --prices）。")
        return

    # 优先展示价格齐全的组合；只有部分价格时排其后
    combos.sort(key=lambda c: (c["price_partial"], -c["score"], c["kcal"]))
    top = combos[:args.top_k]
    print(f"=== 防困点餐推荐（目标: {mode}，Top {len(top)}）===")
    for i, c in enumerate(top, 1):
        if c["price"] is not None and prices:
            price_txt = (f" | 约 ¥{c['price']}" if not c["price_partial"]
                         else f" | ≥ ¥{c['price']}（部分单品待查价）")
        else:
            price_txt = " | 价格以门店为准"
        print(f"{i}. {' + '.join(c['items'])}{price_txt}")
        print(f"   热量 {c['kcal']} kcal | 碳水 {c['carb']} g | 蛋白 {c['protein']} g | 防困分 {c['score']}")
    if args.json:
        print(json.dumps(top, ensure_ascii=False, indent=2))


# ---------------------------------------------------------------- 配送时间估算

def delivery(args):
    """基础模型：出餐 8 min + 骑手接单 5 min + 骑行 distance/20km/h + 交接 4 min。

    系数叠加：午/晚高峰 ×1.3；雨天 ×1.3；暴雨/雪 ×1.6；极端天气另加 10 min 绝对值。
    校园取餐（闸机/电梯/拿外卖排队）统一 +5 min。
    突发缓冲：输出 [估计值, 估计值+缓冲] 区间，缓冲默认 8 min（可调）。
    """
    ride = args.distance_km / 20.0 * 60.0
    base = 8 + 5 + ride + 4
    factor, extra = 1.0, 0.0

    t = parse_time(args.order_time)
    peak = args.peak
    if peak == "auto":
        peak = "high" if (645 <= t <= 780 or 1005 <= t <= 1140) else "normal"
    if peak == "high":
        factor *= 1.3
    weather = args.weather
    if weather == "rain":
        factor *= 1.3
    elif weather in ("storm", "snow"):
        factor *= 1.6
        extra += 10
    elif weather == "heat":
        factor *= 1.1
    if args.campus:
        extra += 5

    est = base * factor + extra
    lo, hi = est, est + args.buffer
    print(f"=== 配送时间估算 ===")
    print(f"距离 {args.distance_km} km | 下单时刻 {fmt_time(t)} | 高峰 {peak} | 天气 {weather} | 校园取餐 {args.campus}")
    print(f"预计送达区间: {fmt_time(t + lo)} ~ {fmt_time(t + hi)}（{lo:.0f} ~ {hi:.0f} 分钟）")
    print(f"含突发缓冲: 商家爆单/骑手不足/恶劣路况/取餐排队 等，按上限规划。")
    if args.json:
        print(json.dumps({"eta_min": round(lo), "eta_max": round(hi),
                          "order_time": fmt_time(t)}, ensure_ascii=False))
    return lo, hi


# ---------------------------------------------------------------- 下单时间反推

def order_time(args):
    """下课即取餐：骑手应恰好在 (下课时间 + 走到取餐点时间) 到达。

    最优下单时刻 = 到达目标时刻 - 配送时长。由于配送是区间，
    给出下单窗口 [目标 - eta_max, 目标 - eta_min]，中点为推荐值。
    """
    target = parse_time(args.class_end) + args.walk_min
    lo_eta, hi_eta = args.eta_min, args.eta_max
    order_lo = target - hi_eta
    order_hi = target - lo_eta
    best = target - (lo_eta + hi_eta) / 2.0
    print(f"=== 最优下单时间 ===")
    print(f"下课 {args.class_end} + 步行 {args.walk_min} min → 目标取餐时刻 {fmt_time(target)}")
    print(f"下单窗口: {fmt_time(order_lo)} ~ {fmt_time(order_hi)}")
    print(f"推荐下单时刻: {fmt_time(best)}（按配送中点估算）")
    print("提示：若App支持『预约送达』，直接预约送达时间为目标取餐时刻更稳；"
          "按窗口上限下单最稳妥（宁可人等餐、不可餐等人）。")
    if args.json:
        print(json.dumps({"order_window": [fmt_time(order_lo), fmt_time(order_hi)],
                          "recommended": fmt_time(best),
                          "target_arrival": fmt_time(target)}, ensure_ascii=False))


# ---------------------------------------------------------------- CLI

def main():
    ap = argparse.ArgumentParser(description="大学生麦当劳点餐规划引擎")
    sub = ap.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("recommend", help="按预算/防困/低碳水推荐套餐")
    r.add_argument("--data", required=True, help="list-nutrition-foods 营养数据文本文件")
    r.add_argument("--prices", help="价格 JSON 文件 [{name, price}]")
    r.add_argument("--budget", type=float, help="预算上限（元），需 --prices")
    r.add_argument("--goal", default="anti_sleep", choices=["anti_sleep", "low_carb", "balanced"])
    r.add_argument("--exclude", default="", help="逗号分隔的排除关键词")
    r.add_argument("--top-k", type=int, default=3)
    r.add_argument("--json", action="store_true")

    d = sub.add_parser("delivery", help="估算配送时间区间")
    d.add_argument("--distance-km", type=float, required=True)
    d.add_argument("--order-time", required=True, help="预计下单时刻 HH:MM")
    d.add_argument("--peak", default="auto", choices=["auto", "high", "normal"])
    d.add_argument("--weather", default="normal", choices=["normal", "rain", "storm", "snow", "heat"])
    d.add_argument("--campus", action="store_true", default=True, help="校园取餐延迟（默认计入）")
    d.add_argument("--no-campus", dest="campus", action="store_false")
    d.add_argument("--buffer", type=float, default=8, help="突发缓冲分钟数")
    d.add_argument("--json", action="store_true")

    o = sub.add_parser("order-time", help="反推最优下单时间")
    o.add_argument("--class-end", required=True, help="下课时间 HH:MM")
    o.add_argument("--eta-min", type=float, required=True, help="配送估计下限（分钟）")
    o.add_argument("--eta-max", type=float, required=True, help="配送估计上限（分钟）")
    o.add_argument("--walk-min", type=float, default=5, help="教室走到取餐点分钟数")
    o.add_argument("--json", action="store_true")

    args = ap.parse_args()
    {"recommend": recommend, "delivery": delivery, "order-time": order_time}[args.cmd](args)


if __name__ == "__main__":
    main()
